// A simple script to demonstrate the GATE Groovy script PR
// Adds a zero length annotation to the start of every document

outputAS.add(0,0,"Test",factory.newFeatureMap())